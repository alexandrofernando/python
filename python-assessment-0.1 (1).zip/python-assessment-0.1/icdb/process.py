"""
        ____
   ____/ / /_
  / __  / __/
 / /_/ / /_
 \__,_/\__/     dealertrack technologies

Welcome to the Internet Car Database v{}
"""
import argparse
import logging

from . import __version__
from .db import db_cursor

# Setup logging
logger = logging.getLogger(__name__)
FORMAT = "%(asctime)-15s %(name)s %(levelname)s %(message)s"
logging.basicConfig(format=FORMAT)
logger.setLevel(logging.ERROR)


def get_input(question):
    return raw_input(question)


def _get_year(year=None):
    """ Keep asking the user for a year until it is finally valid.
    """
    if year:
        if year.isdigit():
            if len(year) == 4:
                return year

    year = get_input("{:>25}".format("Enter car year [2013]: "))
    return _get_year(year)


def create_car():
    """ Let the user input parameters to create a new car, and
    insert it to the database.
    """
    with db_cursor() as db:
        year = _get_year()
        make = get_input("{:>24}".format("Enter car make [Toyota]: "))
        model = get_input("{:>25}".format("Enter car model [Camry]: "))

        row = (year, make, model)

        if not all(row):
            logger.error("One or more of your answers were empty, please try again.")
            return

        print "Inserting a {} {} {} to the database...".format(year, make, model)
        db.execute("INSERT INTO cars VALUES (?, ?, ?)", row)


def import_cars(csv_file):
    logger.error("This has not been implemented yet.")


def update_car():
    logger.error("This has not been implemented yet.")


def delete_car():
    logger.error("This has not been implemented yet.")


def list_cars():
    """ List all cars in the database.
    """
    with db_cursor() as db:
        LAYOUT = "{:<4} {:20} {:20}"
        print LAYOUT.format("Year", "Make", "Model")
        print LAYOUT.format("-" * 4, "-" * 20, "-" * 20)
        for row in db.execute("SELECT * FROM cars"):
            print LAYOUT.format(*row)


def main():
    parser = argparse.ArgumentParser(description=__doc__.format(__version__),
                                     formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('-v', '--verbose',
                        action='store_true',
                        help='be verbose')

    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('-i', '--importcsv',
                         action='store',
                         help='import a CSV file, overwriting the database')
    actions.add_argument('-a', '--add',
                         action='store_true',
                         help='add a car to the database')
    actions.add_argument('-u', '--update',
                         action='store_true',
                         help='update a car in the database')
    actions.add_argument('-d', '--delete',
                         action='store_true',
                         help='delete a car from the database')
    actions.add_argument('-l', '--listcars',
                         action='store_true',
                         help='list the cars in the database')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.INFO)

    if args.importcsv:
        logger.info("importing csv")
        import_cars(args.importcsv)

    if args.add:
        logger.info("adding new car")
        create_car()

    if args.update:
        logger.info("updating a car")
        update_car()

    if args.delete:
        logger.info("deleting a car")
        delete_car()

    if args.listcars:
        logger.info("listing cars")
        list_cars()
