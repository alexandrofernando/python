"""
        ____
   ____/ / /_
  / __  / __/
 / /_/ / /_
 \__,_/\__/     dealertrack technologies

Welcome to the Internet Car Database v{}
"""
import argparse
import logging
import csv

from . import __version__
from .db import db_cursor

# Setup logging
logger = logging.getLogger(__name__)
FORMAT = "%(asctime)-15s %(name)s %(levelname)s %(message)s"
logging.basicConfig(format=FORMAT)
logger.setLevel(logging.ERROR)


def get_input(question):
    return raw_input(question)


def _get_year(year=None):
    """ Keep asking the user for a year until it is finally valid.
    """
    if year:
        if year.isdigit():
            if len(year) == 4:
                return year

    year = get_input("{:>25}".format("Enter car year [2013]: "))
    return _get_year(year)


        

def create_car():
    """ Let the user input parameters to create a new car, and
    insert it to the database.
    """
    with db_cursor() as db:
        year = _get_year()
        make = get_input("{:>24}".format("Enter car make [Toyota]: "))
        model = get_input("{:>25}".format("Enter car model [Camry]: "))

        row = (year, make, model)

        if not all(row):
            logger.error("One or more of your answers were empty, please try again.")
            return

        print "Inserting  a {} {} {} to the database...".format(year, make, model)
        db.execute("INSERT INTO cars VALUES (?, ?, ?)", row)

def import_cars(csv_file):
    """ Let the user input parameters to create a new car, and
    insert it to the database.
    """
    


    f = open('csv-data/car-set-1.csv')
    csv_f = csv.reader(f)
    next(csv_f)


    
    with db_cursor() as db:
        for row in csv_f:

         year = row[0]
         make = row[1]
         model = row[2]

         newRow = (year, make, model)

         if not all(newRow):
            logger.error("One or more of your answers were empty, please try again.")
            return

         print "Inserting  a {} {} {} to the database...".format(year, make, model)
         db.execute("INSERT INTO cars VALUES (?, ?, ?)", newRow)


def update_car():
    """ Let the user input parameters to update year of the car, and
    update from database.
    """
    with db_cursor() as db:
        print "Provide the new year to update then the corresponding make and model"
        year = _get_year()
        make = get_input("{:>24}".format("Enter car make [Toyota]: "))
        model = get_input("{:>25}".format("Enter car model [Camry]: "))

        row = (year, make, model)

        if not all(row):
            logger.error("One or more of your answers were empty, please try again.")
            return

        print "Updating a {} {} {} to the database...".format(year, make, model)
        db.execute("UPDATE Cars SET year=?  WHERE make=? AND model=?", row)




def delete_car():
    """ Let the user input parameters to delete car, and
    from database.
    """
    with db_cursor() as db:
        year = _get_year()
        make = get_input("{:>24}".format("Enter car make [Toyota]: "))
        model = get_input("{:>25}".format("Enter car model [Camry]: "))

        row = (year, make, model)

        if not all(row):
            logger.error("One or more of your answers were empty, please try again.")
            return

        print "Deleting a {} {} {} to the database...".format(year, make, model)
        db.execute("DELETE FROM Cars WHERE year=? and make=? AND model=?", row)




def list_cars():
    """ List all cars in the database.
    """
    with db_cursor() as db:
        LAYOUT = "{:<4} {:20} {:20}"
        print LAYOUT.format("Year", "Make", "Model")
        print LAYOUT.format("-" * 4, "-" * 20, "-" * 20)
        for row in db.execute("SELECT * FROM cars"):
            print LAYOUT.format(*row)


def main():
    parser = argparse.ArgumentParser(description=__doc__.format(__version__),
                                     formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('-v', '--verbose',
                        action='store_true',
                        help='be verbose')

    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('-i', '--importcsv',
                         action='store',
                         help='import a CSV file, overwriting the database')
    actions.add_argument('-a', '--add',
                         action='store_true',
                         help='add a car to the database')
    actions.add_argument('-u', '--update',
                         action='store_true',
                         help='update a car in the database')
    actions.add_argument('-d', '--delete',
                         action='store_true',
                         help='delete a car from the database')
    actions.add_argument('-l', '--listcars',
                         action='store_true',
                         help='list the cars in the database')

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.INFO)

    if args.importcsv:
        logger.info("importing csv")
        import_cars(args.importcsv)

    if args.add:
        logger.info("adding new car")
        create_car()

    if args.update:
        logger.info("updating a car")
        update_car()

    if args.delete:
        logger.info("deleting a car")
        delete_car()

    if args.listcars:
        logger.info("listing cars")
        list_cars()
